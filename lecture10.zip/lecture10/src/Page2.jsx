import React from 'react';

import { useNavigate } from 'react-router-dom';
const Page2 = () => {

 const navigate = useNavigate();

 const goToPage3 = () => {
   navigate('/Page3'); // Navigate to the page3
 };

   return (
     <div>
       <p>This is Page2.</p>
       <button onClick={goToPage3}>Go to page3</button>
     </div>
   );
 };
  export default Page2;