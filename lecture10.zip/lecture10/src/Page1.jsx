import React from 'react';

import { useNavigate } from 'react-router-dom';
const Page1 = () => {

 const navigate = useNavigate();

 const goToPage2 = () => {
   navigate('/Page2'); // Navigate to the page2
 };

   return (
     <div>
       <p>This is Page1.</p>
       <button onClick={goToPage2}>Go to page2</button>
     </div>
   );
 };
  export default Page1;