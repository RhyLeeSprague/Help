import React from 'react';

import { useNavigate } from 'react-router-dom';
const Page3 = () => {

 const navigate = useNavigate();

 const goToPage1 = () => {
   navigate('/Page1'); // Navigate to the Login page
 };

   return (
     <div>
       <p>This is Page3.</p>
       <button onClick={goToPage1}>Go to page1</button>
     </div>
   );
 };
  export default Page3;